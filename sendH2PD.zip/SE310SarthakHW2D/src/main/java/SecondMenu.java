import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SecondMenu extends AbstractMenu {
    private Boolean Condition;
//    Constructor
    SecondMenu(Boolean Condition){
        this.menu = new ArrayList<>();
        this.Condition= Condition;
        this.menu = this.createMenu();

    }

    private ArrayList<String> createMenu() {
        Set<String> menuOptions = Set.of(
                "1) Add a new T/F question",
                "2) Add a new multiple-choice question",
                "3) Add a new short answer question",
                "4) Add a new Essay question",
                "5) Add a new Valid Date question",
                "6) Add a new matching question",
                "7) Back"
        );

        return new ArrayList<>(menuOptions);
    }
    public void generateMultipleChoiceQuestions(MainSurvey survey){
        this.putSurveyQuestion("Enter the correct answer/answers", new SurveyMultipleChoice(),survey);
    }
    public void generateMatchingQuestions(MainSurvey survey){
        this.putSurveyQuestion("", new SurveyAnswersMatching(),survey );
    }



    public void generateBriefAnswerQuestions(MainSurvey survey){
        this.putSurveyQuestion("Enter the correct answer", new SurveyBriefAnswers(),survey);
    }
    public MainSurvey LoaderForMenuItems(MainSurvey current_survey){
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String Curr_Menu;
        String Loop_Condition = "Pass";
        do {
            this.renderMenu();
            try{
                Curr_Menu = reader.readLine();
            }
            catch(IOException e){
                this.menu_output.render("Error reading Input");
                continue;
            }
            switch (Curr_Menu) {
                case "1":
                    this.generateBooleanQuestion(current_survey);
                    break;
                case "2":
                    this.generateMultipleChoiceQuestions(current_survey);
                    break;
                case "3":
                    this.generateBriefAnswerQuestions(current_survey);
                    break;
                case "4":
                    this.generateEssayAnswerQuestions(current_survey);
                    break;
                case "5":
                    this.generateAppropriateDate(current_survey);
                    break;
                case "6":
                    this.generateMatchingQuestions(current_survey);
                    break;
                case "7":
                    return current_survey;
                default:
                    this.menu_output.render("Invalid input");
            }
        }
        while(Loop_Condition=="Pass");

        return null;
    }





    public void generateEssayAnswerQuestions(MainSurvey survey){
        this.putSurveyQuestion("Enter the correct answer", new Essay(), survey );
    }
    public void generateBooleanQuestion(MainSurvey survey){

        this.putSurveyQuestion("Enter the correct answer T/F", new SurveyTrueFalse(),survey);
    }
    public void generateAppropriateDate(MainSurvey survey){
        this.putSurveyQuestion("A date should be entered in the following format: YYYY-MM-DD", new ValidDate(), survey);
    }

    public void putSurveyQuestion(String prompt,Questions question,MainSurvey survey ){

        Questions Object_Question = question;
        Object_Question.QuestionLoader();

        if (this.Condition){
       
            Object_Question.CorrectAnswerLoader(prompt);
        }
        survey.putQuestionInSurvey(Object_Question);
        this.menu_output.render("question added successfully");
    }

}
