
import java.util.*;
import java.io.Serializable;
public class CorrectAnswers implements Serializable{
    private ArrayList<Questions> correct_answers;
    private ArrayList<Questions> total_responses;

    public ArrayList<Questions> getCorrect_answers(){
        return this.correct_answers;
    }
    public ArrayList<Questions> getTotal_responses(){
        return this.total_responses;
    }

    public void setAnswersCorrect(ArrayList<Questions> correct_answers){
        this.correct_answers=correct_answers;
    }

    public void setTotalResponses(ArrayList<Questions> total_responses){
        this.total_responses=total_responses;
    }
}
