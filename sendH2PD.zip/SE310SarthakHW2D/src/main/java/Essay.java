import java.util.*;
public class Essay extends Questions {

//    using array list for essay answers
    ArrayList<String> Essay_Answers;

//    Constructor
    public Essay(){
        this.Essay_Answers = new ArrayList<>();
    }

    @Override
    public void CorrectAnswerLoader(String content) {

        String loop_condition = "Pass";
        while(loop_condition=="Pass") {
            String curr_res = this.Question_Input.GetThroughPrompt(content);
            if (curr_res != null) {
                this.Essay_Answers.add(curr_res);
                return;
            }
            else{
                this.Question_Output.render("invalid.");
            }
        }

    }
    @Override
    public void QuestionEdit(String Condition){}
//    Edits a question
//    No return since void
//    Function parameter: None

    public void QuestionEdit(){
        String condition = "Pass";
        while (condition=="Pass"){
            String prompt_input = this.Question_Input.GetThroughPrompt("1. Modify Prompt  2. Go Back");
            if (prompt_input.equalsIgnoreCase("2")){
                condition="Failed";
            }
            else if (prompt_input.equalsIgnoreCase("1")){
                this.PromptLoader("Enter a new prompt");
            }
            else{
                this.Question_Output.render("Invalid choice");
            }
        }
    }


    @Override
    public void renderTabs() {
        this.Question_Output.render("Survey Tabulation:");
        int length=this.Essay_Answers.size();
        int i=0;
        while(i <length){
            this.Question_Output.render(this.Essay_Answers.get(i));
            i++;
        }
    }
    @Override
    public void renderResponses() {
        this.Question_Output.render("Response:");
        int length=this.Essay_Answers.size();
        int i=0;
        while(i <length){
            this.Question_Output.render(this.Essay_Answers.get(i));
            i++;
        }
    }

    @Override
    public Integer getAccuratePoints() {
        return 0;
    }

    //  Render essay question prompt
//    no parameters or return
    @Override
    public void QuestionLoader(){
//        utilizing prompt loader function from questions class
        this.PromptLoader("Enter prompt for your Essay Question.");
    }

//    Prompts the answer
//    returns int
//    Function parameter: None
    @Override
    public Integer AnswerPrompter(String Condition){
    this.Essay_Answers.add(this.Question_Input.GetThroughPrompt("Enter your Essay"));
    return 0;
    }

//    render/display the prompt along with instructions
    @Override
    public void render(String Condition){
        this.Question_Output.render("Essay prompt:" +" "+ this.Question_Instructions);
    }

}
