import java.io.*;
import java.io.Serializable;

public abstract class Questions implements Serializable {
    protected Output Question_Output;
    protected Input Question_Input;

    protected String Question_Instructions;

// Constructor
    public Questions(){
        this.Question_Input = new Input();
        this.Question_Output = new Output();
    }

//  Load a question
//    No return since void
//    No Function paramters
    public abstract void QuestionLoader();
    public abstract void renderResponses();
//  Loads a prompt
//    No returns since void
//    Function paramter: prompt(String)
    public void PromptLoader(String prompt){
        this.Question_Instructions=this.Question_Input.GetThroughPrompt(prompt);
    }
    public abstract Integer getAccuratePoints();




//  Edits a question
//    No return since void
//    Function parameter: Condition(String): is overloaded in some classes
    public abstract void QuestionEdit(String Condition);

//    Prompts the answer
//    returns int
//    Function parameter: Condition(String)
    public abstract Integer AnswerPrompter(String Condition);

//    Load the correct answer
//    no return since void
//    Function Paramter: Answer(String)
    public void CorrectAnswerLoader(String Answer){};
    public abstract void renderTabs();
//  render/display the questions
//    no return
//    Function parameter: Condition(String): is overloaded in some classes
    public abstract void render(String Condition);
}
