public class ValidDate extends Essay {

    private String currentSurveyAnswer;

    public ValidDate() {
        this.currentSurveyAnswer = "";
    }

//    @Override
//    public Integer answerPrompter(String condition) {
//        String response = this.Question_Input.getSurveyInput();
//        this.currentSurveyAnswer = response;
//        return 0;
//    }

    @Override
    public void render(String condition) {
        this.Question_Output.render("What is today's date (in correct format: YYYY-MM-DD)?");
    }


    @Override
    public void QuestionLoader(){
        this.PromptLoader("Enter a prompt for Date");
    }
}
