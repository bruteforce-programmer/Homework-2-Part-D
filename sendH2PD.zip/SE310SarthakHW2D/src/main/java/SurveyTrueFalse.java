import java.util.*;

public class SurveyTrueFalse extends SurveyMultipleChoice {


    public SurveyTrueFalse() {

        this.surveyAvailableOptions =new ArrayList<>();
        this.tabulationList = new HashMap<>();
        this.surveyAvailableOptions.add("T");
        this.surveyAvailableOptions.add("F");
        this.tabulationList.put("T",0);
        this.tabulationList.put("F",0);

    }

    @Override
    public void render(String condition) {
        super.render(condition);
        this.Question_Output.render("Enter T for True, F for False");
    }
    @Override
    public void QuestionLoader(){
        this.PromptLoader("Enter prompt for True/False Question");
        this.tabulationList=new HashMap<>();
        this.tabulationList.put("T",0);
        this.tabulationList.put("F",0);

    }


    @Override
    public void CorrectAnswerLoader(String content) {
        String loop_condition = "Pass";
        while(loop_condition=="Pass"){
            String curr_res = this.Question_Input.GetThroughPrompt(content);
            if(curr_res != null){
                if(!(curr_res.equals("F") || curr_res.equals("T"))){
                    this.Question_Output.render("must be T or F");

                }else{
                    this.accurateAnswers.add(curr_res);
                    return;
                }
            }
        }
    }
    @Override
    public void QuestionEdit(String Condition){
        String loop_condition = "Pass";
        while(loop_condition=="Pass"){
            if (Condition.equals("Pass")){
            String curr_res = this.Question_Input.GetThroughPrompt("1) Modify prompt 2) Modify correct answer 3) Back");
            if (curr_res.equals("2")){
                while (loop_condition=="Pass"){
                    String res = this.Question_Input.GetThroughPrompt("Enter new answer: T/F");
                    if(!(res.equals("T") || res.equals("F"))) {
                        this.Question_Output.render("invalid choice");
                        continue;
                    }
                    else{
                            this.accurateAnswers.set(0,res);
                            break;
                    }
                }
            }
            else if (curr_res.equals("1")){
                this.PromptLoader("Enter new prompt");
            }
            else if (curr_res.equals("3")){
                return;
            }
            else{
                this.Question_Output.render("Invalid choice");
            }}
            else{
                String curr_res = this.Question_Input.GetThroughPrompt("1) Modify prompt 2) Back");
                if (curr_res.equals("1")){
                    this.PromptLoader("Enter new prompt");
                }
                else if(curr_res.equals("2")){
                    return;
                }
                else{
                    this.Question_Output.render("Invalid choice");
                }
            }
        }
    }
    @Override
    public void EditCorrectQuestionChoices() {
    }
    @Override
    public Integer AnswerPrompter(String condition) {
        this.responsesFromUsers = new ArrayList<>();
        String loop_condition = "Pass";
        while (loop_condition.equals("Pass")) {
            String response = this.Question_Input.GetThroughPrompt("Enter T/F");
            if (response.equalsIgnoreCase("T") || response.equalsIgnoreCase("F")) {
                if (response.equals("F")) {
                    this.tabulationList.replace("F", this.tabulationList.get("F") + 1);
                } else {
                    this.tabulationList.replace("T", this.tabulationList.get("T") + 1);
                }
                this.responsesFromUsers.add(response);
                break;
            } else {
                this.Question_Output.render("invalid choice. Enter T/F only");
            }
        }
        this.surveyResponses.add(this.responsesFromUsers);
        if (this.accurateAnswers.size()==0){
            return 0;
        }
        if (!this.accurateAnswers.get(0).equals(this.accurateAnswers.get(0))){
            return 0;
        }
        return 10;
    }


    @Override
    public void EditQuestionChoices() {
        super.EditQuestionChoices();
    }
}
