import java.io.*;
import java.util.*;

public class Input implements Serializable{
    private Output Survey_Output;

//    Constructor
    public Input(){
        this.Survey_Output = new Output();
    }

//    Get numeric input
//    Parameter: Survey_Prompt(String)
//    Returns Integer
    public Integer getNumberInputThroughPrompt(String Survey_Prompt) {
        String conditionCheck = "Pass";
        while (conditionCheck == "Pass"){
//   Using try/catch to avoid errors for Integer parsing/conversion as suggested by lint extension
            try {
                if ((Integer.parseInt(this.GetThroughPrompt(Survey_Prompt)))>0){
                    return (Integer.parseInt(this.GetThroughPrompt(Survey_Prompt)));
                }
                else{
//                  System.out.println("must be greater than 0");
//                  Using output class's method for console output as recommended by TA.
                    this.Survey_Output.render("must be greater than 0");
                    continue;
                }
            } catch (Exception error) {
//              System.out.println("must be an integer");
//              Using output class's method for console output as recommended by TA.
                this.Survey_Output.render("must be an integer");
                continue;
            }
        }
//      adding a return statement to satisfy lint error.
        return null;
    }

//  Get input through prompt
//   Parameters: Survey_Prompt(String)
//   Returns String
    public String GetThroughPrompt(String Survey_Prompt){
        if (!((Survey_Prompt.trim()).length()==0)){
            this.Survey_Output.render(Survey_Prompt);
        }
        return this.getSurveyInput();

    }

//    Get many inputs
//    Parameters: Survey_Prompt(String), num(Integer)
//    Returns Set<String>
public Set<String> getMultipleSurveyInput(String Survey_Prompt, int num) {

    // Use HashMap to store inputs
    Map<String, Integer> inputMap = new HashMap<>();
    Set<String> Survey_Inputs = new HashSet<>();

    int i = 1;
    while (i <= num) {
        String input = GetThroughPrompt(Survey_Prompt + " " + i);

        while (inputMap.containsKey(input)) {
            this.Survey_Output.render("You have already entered this choice. Please enter a different one.");
            input = GetThroughPrompt(Survey_Prompt + " " + i);
        }

        inputMap.put(input, 1); // Store input as key in the HashMap

        Survey_Inputs.add(input);
        i++;
      
    }
  
    return Survey_Inputs;
}


public String getSurveyInput(){
//  following open code template from https://www.programiz.com/java-programming/inputstreamreader
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    String condition_Check = "Pass";
    while(condition_Check=="Pass"){
        try{
            String Buffer_Input = reader.readLine().trim();
            if (Buffer_Input.length()==0){
//                changed after testing since it stops program
//                throw new IllegalArgumentException("Input cannot be blank");
                this.Survey_Output.render("it cannot be blank");
                continue;
            }
            return Buffer_Input;
        }
        catch(IOException e){
            this.Survey_Output.render("incorrect input");

        }

    }
    return null;
}



//    following open code template from https://www.geeksforgeeks.org/java-io-fileinputstream-class-java/
public MainSurvey ProcessDeserialization(String File_Path){
    try {
        FileInputStream fileInputStream = new FileInputStream(File_Path);
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        MainSurvey survey = (MainSurvey) objectInputStream.readObject();
        fileInputStream.close();
        objectInputStream.close();
        return survey;
    } catch (IOException | ClassNotFoundException e) {
        this.Survey_Output.render(e);
        return null;
    }
}
}
