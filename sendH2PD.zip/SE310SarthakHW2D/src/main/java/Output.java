import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.io.Serializable;
import java.io.ObjectOutputStream;

public class Output implements Serializable {

//    private Input Survey_Input;
//
//    // Constructor
//    public Output() {
//        this.Survey_Input = new Input();
//    }

//  following open code template from https://www.geeksforgeeks.org/java-io-fileinputstream-class-java/
    public void processSerialization(Object object, String path){
        try{
            FileOutputStream file = new FileOutputStream(path);
            ObjectOutputStream out = new ObjectOutputStream(file);
            out.writeObject(object);
            file.close();
            out.close();
        }catch (IOException error){
            this.render(error);
        }
    }


    public void render(Object object){
        System.out.println(object);
    }
    private void renderStringList(ArrayList<String> Elements, int index) {
        if (index < Elements.size()) {
            this.render(Elements.get(index));
            renderStringList(Elements, index + 1);
        }
    }
    public void renderList(ArrayList<String> Elements){
        renderStringList(Elements,0);
    }
    public void renderSingleLineTogether(Object object){
//        System.out.print(object2);
//        System.out.print(" ");
        System.out.print(object);
    }


}
