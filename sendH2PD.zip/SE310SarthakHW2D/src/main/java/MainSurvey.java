import java.io.*;
import java.util.*;

public class MainSurvey implements Serializable{

    protected int curr_score = 0;
    private Output Survey_Output;
    protected ArrayList<Questions> Survey_Questions;
    String Current_Survey_Name;
    protected int final_score = 0;
    protected HashMap<String,String> totalSurveys;


    public MainSurvey(){
        this.Survey_Questions= new ArrayList<>();
    }



    public void setNameOfCurrentSurvey(String Survey_Name){
        this.Current_Survey_Name = Survey_Name;
    }
    public Questions getCurrentQuestion(Integer index){
        int curr_index= index-1;
        return this.Survey_Questions.get(curr_index);
    }
    public void putQuestionInSurvey(Questions SurveyQuestions){
        this.Survey_Questions.add(SurveyQuestions);
    }

    public ArrayList<Questions> retrieveSurveyQuestions(){
        return this.Survey_Questions;
    }
    public Integer getLengthOfQuestion(){
        int len = this.Survey_Questions.size();
        return len;
    }

    public void renderGrades() {
        Iterator<Map.Entry<String, String>> iterator = this.totalSurveys.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key = entry.getKey();
            String value = entry.getValue();

            this.Survey_Output.render("id " + key + ": " + value);
        }
    }
    public void conductCurrentSurvey(String Condition){
//        resetting
        this.Survey_Output = new Output();
        this.curr_score=0;
        this.final_score=0;
        int i =0;
        if (!(Condition=="Pass")){
            while(i<this.Survey_Questions.size()){

                this.Survey_Questions.get(i).render("Pass");
                this.Survey_Questions.get(i).AnswerPrompter("Fail");
                i++;
            }
        }

        while(i<this.Survey_Questions.size()){
          

            this.Survey_Questions.get(i).render("Fail");
            this.final_score+=this.Survey_Questions.get(i).AnswerPrompter("Pass");
            this.curr_score+=this.Survey_Questions.get(i).getAccuratePoints();
            i++;
        }
        this.Survey_Output.render("Total score is " + this.curr_score + "/" + this.final_score);
//        this.totalSurveys.put(this.Current_Survey_Name, this.curr_score + "/" + this.final_score);
    }

    protected void render_tabs(){
        int i =0;
        while(i<this.Survey_Questions.size()){

            
            this.Survey_Questions.get(i).renderTabs();
            i++;
        }
    }







}
