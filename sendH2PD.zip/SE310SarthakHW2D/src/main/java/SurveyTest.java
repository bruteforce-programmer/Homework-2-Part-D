import java.util.*;

public class SurveyTest extends MainSurvey{
    private List<Questions> questions;
    private List<List<String>> answers;

    public SurveyTest() {
        questions = new ArrayList<>();
        answers = new ArrayList<>();
    }

    public void putQuestionInSurvey(Questions question, List<String> answerOptions) {
        questions.add(question);
        answers.add(answerOptions);
    }

    public void printTest() {
        for (int i = 0; i < questions.size(); i++) {
            Questions question = questions.get(i);
            List<String> answerOptions = answers.get(i);

            System.out.println("Question " + (i + 1) + ": " + question.Question_Input.GetThroughPrompt(""));

            if (question instanceof SurveyMultipleChoice) {
                System.out.println("Options:");
                for (String option : answerOptions) {
                    System.out.println(option);
                }
            }
            System.out.println();
        }
    }

    public void gradeTest(List<List<String>> userResponses) {
        int totalPoints = 0;

        for (int i = 0; i < questions.size(); i++) {
            Questions question = questions.get(i);
            List<String> answerOptions = answers.get(i);
            List<String> userAnswer = userResponses.get(i);

            int questionPoints = question.getAccuratePoints();
            totalPoints += questionPoints;

            System.out.println("Question " + (i + 1) + ": " + question.Question_Input.GetThroughPrompt(""));

            if (question instanceof SurveyMultipleChoice) {
                System.out.println("Options:");
                for (String option : answerOptions) {
                    System.out.println(option);
                }
                System.out.println("User's Answer: " + userAnswer);
            }

            System.out.println("Points: " + (userAnswer.equals(answerOptions) ? questionPoints : 0));
            System.out.println();
        }

        System.out.println("Total Points: " + totalPoints);
    }
}