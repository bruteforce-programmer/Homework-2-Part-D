import java.util.*;

public abstract class AbstractMenu {
    protected ArrayList<String> menu;
    protected Output menu_output;
    protected Input menu_input;

// Constructor
    AbstractMenu(){
        menu_output = new Output();
//
        menu_input = new Input();

    }
//    display/render the menu.
//    No returns since void
    public void renderMenu(){
        Output output = new Output();
        output.renderList(this.menu);
    }
}
