import java.util.*;

public class SurveyMultipleChoice extends Questions {

    protected ArrayList<String> surveyAvailableOptions;
    protected ArrayList<String> accurateAnswers;
    protected HashMap<String, Integer> tabulationList;
    protected ArrayList<ArrayList<String>> surveyResponses;
    protected ArrayList<String> responsesFromUsers;

    public SurveyMultipleChoice() {
        this.surveyAvailableOptions = new ArrayList<>();
        this.accurateAnswers = new ArrayList<>();
        this.tabulationList = new HashMap<>();
        this.surveyResponses = new ArrayList<>();
        this.responsesFromUsers = new ArrayList<>();
    }

    public void insertSurveyChoice(String option) {
        this.surveyAvailableOptions.add(option);
        this.tabulationList.put(option, 0);
    }

    public void insertSurveyAnswer(String answer) {
        this.accurateAnswers.add(answer);
    }

    public void deleteAnswer(int index) {
        this.accurateAnswers.remove(index);
    }

    public void choiceSetter(int index, String option) {
        this.surveyAvailableOptions.set(index, option);
    }

    public void resetResponses() {
        this.surveyResponses.clear();
    }

    @Override
    public void render(String condition) {
        if (condition.equals("Pass")) {
            this.Question_Output.render("Enter all the correct answer(s) (A/B/...), followed by 'done'");
        } else {
            this.Question_Output.render("Enter all the correct answer(s) (A/B/...), followed by 'done'");
        }
    }

    @Override
    public void renderResponses() {
        this.Question_Output.render("Replies:");
        for (ArrayList<String> response : this.surveyResponses) {
            StringBuilder currTemp = new StringBuilder();
            for (String answer : response) {
                currTemp.append(answer).append(",");
            }
            this.Question_Output.render(currTemp.substring(0, currTemp.length() - 1));
        }
    }

    @Override
    public Integer getAccuratePoints() {
        return 10;
    }

    @Override
    public void renderTabs() {
        this.Question_Output.render("Tabulate:");
        for (Map.Entry<String, Integer> entry : this.tabulationList.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();

            this.Question_Output.render(value.toString());

            this.Question_Output.render(key + "->" + value.toString());

            this.Question_Output.render("");
        }
    }
    public void QuestionLoader() {

        Integer responseCounter=0;

        this.PromptLoader("Enter a prompt for your question");
        responseCounter = this.Question_Input.getNumberInputThroughPrompt("Enter the number of choices for MCQ");
        String loop_condition = "Pass";
        while (loop_condition=="Pass"){


            if (responseCounter<2){
                this.Question_Output.render("Add at least 2 choices for MCQ");
            }
            else if(responseCounter>1000){
                this.Question_Output.render("try again with less than 1000 choices");
            }
            else if(responseCounter == null){
                System.out.println("wrong");
                continue;
            }
            else{
                break;
            }
        }
      
        this.surveyAvailableOptions = new ArrayList<>(this.Question_Input.getMultipleSurveyInput("enter choice",responseCounter));
        this.TabsSetter();
    }
    public void TabsSetter(){
        Integer length = this.surveyAvailableOptions.size();
        int i =0;
        while (i<length){
            String curr_character = Character.toString((char)(i+65));
            if (this.tabulationList.get(curr_character)==null){
                this.tabulationList.put(curr_character, 0);
            }
            i++;
        }
    }
    public void renderSpecifications(ArrayList<String> curr_options, String Condition){
        int i=0;
        if (Condition=="Fail"){
            while (i<curr_options.size()){
                this.Question_Output.renderSingleLineTogether((i + 1 + ")" + curr_options.get(i) + " " + "\n"));
                i++;
            }
        }
        else{
            while (i<curr_options.size()){
                this.Question_Output.renderSingleLineTogether((char) (i + 65) + ")" + curr_options.get(i) + " " + "\n");
                i++;
            }
        }

    }

    public void EditCorrectQuestionChoices(){
        String loop_conditiion = "Pass";
        while(loop_conditiion=="Pass"){
            this.Question_Output.render("which of the following do you want to modify? Select index");
            this.Question_Output.render("1) add correct answer  2) delete correct answer  3) back ");
            String curr_response = this.Question_Input.getSurveyInput();
            if (curr_response=="3"){
                return;
            }
            else if(curr_response=="2"){
                if(this.accurateAnswers.size()>2){
                    while (loop_conditiion=="Pass"){
                        this.renderSpecifications(this.accurateAnswers,"Fail");
                        Integer response_curr = this.Question_Input.getNumberInputThroughPrompt("\n" + "answer to delete"  + " in integer");
                        if (response_curr<1|| response_curr == null||response_curr>this.accurateAnswers.size()){
                            this.Question_Output.render("Index you entered is invalid");
                            continue;
                        }
                        this.deleteAnswer(response_curr -1);
                        this.Question_Output.render("Answer deleted");
                        break;
                    }

                }
                else{
                    this.Question_Output.render("you cannot delete more");
                    break;
                }
            }
            else if(curr_response=="1"){
                while(loop_conditiion=="Pass"){
                    if(this.accurateAnswers.size()==this.surveyAvailableOptions.size()){
                        this.Question_Output.render("you can't add anymore correct answer");
                        break;
                    }
                    while(this.accurateAnswers.size()<this.surveyAvailableOptions.size()){
                        this.renderSpecifications(this.surveyAvailableOptions, "Fail");
                        Integer res_curr = this.Question_Input.getNumberInputThroughPrompt("\n" + "answer" + " in integer index");
                        if (res_curr < 1 || res_curr > this.surveyAvailableOptions.size() || res_curr == null) {
                            this.Question_Output.render("The index you have entered is invalid ");
                            continue;
                        }
                        String chosen_response = this.surveyAvailableOptions.get(res_curr -1);
                        if (!this.surveyAvailableOptions.contains(chosen_response)||this.accurateAnswers.contains(chosen_response)){
                            this.Question_Output.render("the choice you entered is not found/already entered");
                        }
                        else{
                            this.insertSurveyAnswer(chosen_response);
                            this.Question_Output.render("Correct choice inserted");
                            break;
                        }
                    }

                }
            }
            else{
                this.Question_Output.render("invalid input");

            }
        }
    }

    public void EditQuestionChoices() {
        String loop_condition = "Pass";
        while (loop_condition == "Pass") {
            this.Question_Output.render("Select index to modify?");
            this.Question_Output.render("1) add choice  2) delete choice  3) modify choice 4) modify prompt 5) back");
            String responseGetter = this.Question_Input.getSurveyInput();
            if(responseGetter.equalsIgnoreCase("5")){
                return;
            }
            else if(responseGetter.equalsIgnoreCase("4")){
                this.PromptLoader("Enter new prompt");
                this.Question_Output.render("Prompt edited");

            }
            else if(responseGetter.equalsIgnoreCase("3")){
                this.renderSpecifications(this.surveyAvailableOptions,"Fail");
                Integer res_user = this.Question_Input.getNumberInputThroughPrompt("Enter the index of the choice you want to modify");
                try{
                    String curr_character = this.surveyAvailableOptions.get(res_user -1);
                    String res_user_temp = this.Question_Input.GetThroughPrompt("Enter replacement text for it");
                    if(this.surveyAvailableOptions.contains(res_user_temp)){
                        this.Question_Output.render("Already exists");
                        continue;
                    }
                    this.choiceSetter(res_user - 1, res_user_temp);
                    if(this.accurateAnswers.contains(curr_character)){
                        this.accurateAnswers.set(this.accurateAnswers.indexOf(curr_character),res_user_temp);

                    }
                    this.Question_Output.render("Replaced successfully");
                }
                catch(IndexOutOfBoundsException e){
                    this.Question_Output.render("Select from list");
                }
            }
            else if(responseGetter.equalsIgnoreCase("2")){
                if (this.surveyAvailableOptions.size() < 3) {
                    this.Question_Output.render("you cannot delete more choices if the number of choices left is less than 2");
                }
                this.renderSpecifications( this.surveyAvailableOptions,"Fail");
                Integer res_temp = this.Question_Input.getNumberInputThroughPrompt("Enter the index for the choice you want to delete");
                try {
                    this.accurateAnswers.remove(this.surveyAvailableOptions.get(res_temp - 1));
                    this.deleteAnswer(res_temp - 1);
                    this.Question_Output.render("Removed successfully");
                } catch (IndexOutOfBoundsException error) {
                    this.Question_Output.render("Select from the list");
                }
            }
            else if(responseGetter.equalsIgnoreCase("1")){
                while(loop_condition=="Pass"){
                    String resTemp = this.Question_Input.GetThroughPrompt("Enter a new choice");
                    if (this.surveyAvailableOptions.contains(resTemp)) {
                        this.Question_Output.render("It already exists");
                        continue;
                    }
                    this.insertSurveyChoice(resTemp);
                    this.Question_Output.render("Added successfully");
                    break;
                }
            }
            else{
                this.Question_Output.render("Invalid Input");
            }
        }
    }



    @Override
    public void CorrectAnswerLoader(String content) {
     
        String loop_condition = "Pass";
        while(loop_condition=="Pass") {
            String curr_res = this.Question_Input.GetThroughPrompt(content);
            if (curr_res != null) {
                this.accurateAnswers.add(curr_res);
                return;
            }
            else{
                this.Question_Output.render("invalid.");
            }
        }

    }

    //  Edits a question
//    No return since void
//    Function parameter: Condition(String): is overloaded in some classes
    @Override
    public void QuestionEdit(String Condition){
        if (Condition=="Fail"){
            this.EditQuestionChoices();
        }
        else{
            String loop_condition = "Pass";
            while (loop_condition=="Pass"){
                String currResponse = this.Question_Input.GetThroughPrompt("Type 'A' to modify choices. Type 'B' to modify answers");
                switch (currResponse){
                    case "A":
                        this.EditQuestionChoices();
                        return;
                    case "B":
                        this.EditCorrectQuestionChoices();
                        return;
                    default:
                        this.Question_Output.render("invalid choice");
                }
            }
        }
    }

    public Integer AnswerPrompter(String condition) {
        this.tabulationList.replaceAll((key, value) -> 0);
        this.responsesFromUsers = new ArrayList<>();
        render(condition);
        if (condition.equals("Fail")) {
            while (this.responsesFromUsers.size() < this.surveyAvailableOptions.size()) {
                String response = this.Question_Input.getSurveyInput();
                if (response.equalsIgnoreCase("done")) {
                    if (this.responsesFromUsers.size() < 1) {
                        this.Question_Output.render("Please enter at least 1 answer");
                        continue;
                    }
                    break;
                }
                int currIndex = (int) response.toCharArray()[0] - 65;
                if (this.responsesFromUsers.contains(response) || currIndex < 0 || currIndex > this.surveyAvailableOptions.size() - 1) {
                    this.Question_Output.render("Invalid choice or already entered");
                } else {
                    this.tabulationList.replace(response, this.tabulationList.get(response) + 1);
                    this.responsesFromUsers.add(response);
                }
            }
        } else {
            while (this.responsesFromUsers.size() < this.accurateAnswers.size()) {
                String response = this.Question_Input.getSurveyInput();
                if (response.equalsIgnoreCase("done")) {
                    if (this.responsesFromUsers.size() < 1) {
                        this.Question_Output.render("Please enter at least 1 answer");
                        continue;
                    }
                    break;
                }
                int currIndex = (int) response.toCharArray()[0] - 65;
                if (this.responsesFromUsers.contains(response) || currIndex < 0 || currIndex > this.surveyAvailableOptions.size() - 1) {
                    this.Question_Output.render("Invalid choice or already entered");
                } else {
                    this.tabulationList.replace(response, this.tabulationList.get(response) + 1);
                    this.responsesFromUsers.add(response);
                }
            }
        }
        this.surveyResponses.add(this.responsesFromUsers);
        if (!this.accurateAnswers.equals(this.responsesFromUsers)) {
            return 0;
        }
        if (this.accurateAnswers.size() == 0) {
            return 0;
        }
        return getAccuratePoints();
    }
}
