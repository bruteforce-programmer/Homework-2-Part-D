import java.util.*;

public class MenuForTest extends MenuForSurvey {
    MenuForTest(){
        this.menu = new ArrayList<>();
        this.menu = this.createMenu();

    }

    private ArrayList<String> createMenu() {
        Set<String> menuOptions = Set.of(
        "1) Create a new test",
        "2) Display a test with correct answers",
        "3) Load a test",
        "4) Save current test",
        "5) Take a test",
        "6) Modify a test",
        "7) Tabulate a test",
        "8) Grade a test",
        "9) Back"
        );

        return new ArrayList<>(menuOptions);
    }
    @Override
    public SurveyTest getNewSurvey(){
        return new SurveyTest();
    }
    @Override
    public String Tester(){
        return "Pass";
    }

    @Override
    public String getDesiredFileType(){
        return "test";
    }


    @Override
    public void ParseMenuItems() {
        String loop_condition = "Pass";
        while (loop_condition.equals("Pass")) {
            this.renderMenu();
            String curr_response_from_user = this.menu_input.GetThroughPrompt("");
            switch (curr_response_from_user) {
                case "1":
                    this.generateNewSurvey();
                    break;
                case "2":
                    this.renderCurrentSurvey();
                    break;
                case "3":
                    this.desiredSurveyLoader();
                    break;
                case "4":
                    this.CurrentSurveySaver(this.Current_Survey);
                    break;
                case "5":
                    this.conductSurvey();
                    break;
                case "6":
                    this.surveyEditor();
                    break;
                case "7":
                    this.renderTabs();
                    break;
                case "8":
                    this.calculateGrade();
                    break;
                case "9":
                    if(this.returnBack()){
                        return;
                    }
                    break;
                default:
                    this.menu_output.render("Invalid input");
            }
        }
    }

    protected void renderTabs(){
        MainSurvey curr_survey = this.renderAllContentFiles("render/display");
        curr_survey.render_tabs();
   }
}
