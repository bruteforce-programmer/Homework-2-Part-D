import java.util.*;

public class MainMenu extends AbstractMenu {
    private MenuForSurvey Initial_Menu;

    MainMenu() {
        this.menu = new ArrayList<>();
        this.menu = createMenu();
        this.ParseMenuItems();
    }

    private ArrayList<String> createMenu() {
        Set<String> menuOptions = Set.of(
                "1) Survey",
                "2) Test",
                "3) Quit"

        );
        return new ArrayList<>(menuOptions);

    }
    public void ParseMenuItems(){
        this.menu_output.render("Survey");
        String loop_condition = "Pass";
        while(loop_condition=="Pass"){
            this.renderMenu();
            String curr_response_from_user = this.menu_input.GetThroughPrompt("");
            switch (curr_response_from_user){
                case "1":
                    Initial_Menu =new MenuForSurvey();
                    Initial_Menu.ParseMenuItems();
                    break;
                case "2":
                    Initial_Menu =new MenuForTest();
                    Initial_Menu.ParseMenuItems();
                    break;
                case "3":
                    this.menu_output.render("Survey End");
                    System.exit(0);
                    break;
                default:
                    this.menu_output.render("Invalid input");
                    continue;
            }
        }
    }
}
