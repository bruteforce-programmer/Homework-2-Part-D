import java.io.*;
import java.util.*;

public class MenuForSurvey extends AbstractMenu implements Serializable{

    protected MainSurvey Current_Survey;
    protected String delimiter;
    protected boolean modified_Unsaved_current_survey;
    protected String current_Path;
    protected String current_survey_name;

    MenuForSurvey(){
        this.menu = new ArrayList<>();
        this.modified_Unsaved_current_survey=false;
        this.delimiter=File.separator;
        this.menu=this.createMenu();
    }

    private ArrayList<String> createMenu() {
        Set<String> menuOptions = Set.of(
                "1) Create a new survey",
                "2) Display a survey",
                "3) Load a survey",
                "4) Save current survey",
                "5) Take the current survey",
                "6) Modify the current survey",
                "7) Grade the current survey",
                "8) Back"
        );

        return new ArrayList<>(menuOptions);
    }
    public String getDesiredFileType(){
        String FileType = "survey";
        if (FileType.equalsIgnoreCase("survey")){
            return FileType;
        }
        return "non-survey";

    }

    public void conductSurvey(){
        MainSurvey curr_survey = this.renderAllContentFiles("take");
        curr_survey.conductCurrentSurvey(this.Tester());
        this.menu_output.processSerialization(curr_survey, "Serializable" + this.delimiter + this.getDesiredFileType() +"s" + this.delimiter + this.current_survey_name);
        this.menu_output.render(this.getDesiredFileType() +" has been conducted and saved");
    }

    public MainSurvey getNewSurvey(){
        return new MainSurvey();
    }
    public MainSurvey renderAllContentFiles(String Command){
//        resetting path
        this.current_Path = "";
        File[] files_list = getSurveyFiles();
        if (this.Current_Survey==null && files_list.length<1){
            this.menu_output.render("No " + this.getDesiredFileType() + "s are stored");
            return null;
        }
        this.menu_output.render("Select the file you want to "+Command);
        int i =1;
        while(i<files_list.length+1){
            this.menu_output.render((i) + "." +files_list[i-1].getName());
            i++;
        }
        int Counter_files = files_list.length;
        if (Command.equals("render/display")) {
            displayCurrentSurveyOption(Counter_files);
        }
        String loop_condition = "Pass";
        while(loop_condition=="Pass"){
            int OptionResponse = getSelectedOption();
            if (OptionResponse == 0) {
                continue;
            }
            if (OptionResponse == Counter_files && Command.equals("render/display")){
                if(this.Current_Survey==null){
                    this.menu_output.render("No survey loaded or is currently active");
                    return null;
                }
                else{
                    return this.Current_Survey;
                }
            }
            if (OptionResponse != 0 && OptionResponse > 0 && OptionResponse <= Counter_files) {
                setSelectedPathAndSurveyName(files_list, OptionResponse);
                return this.menu_input.ProcessDeserialization(this.current_Path);
            }
        }
        return null;
    }
    public void ParseMenuItems(){
        String Condition = "Pass";
        while(Condition=="Pass"){
            this.renderMenu();
            String response= this.menu_input.GetThroughPrompt("");
            switch (response) {
                case "1":
                    this.generateNewSurvey();
                    break;
                case "2":
                    this.renderCurrentSurvey();
                    break;
                case "3":
                    this.desiredSurveyLoader();
                    break;
                case "4":
                    this.CurrentSurveySaver(this.Current_Survey);
                    break;
                case "5":
                    this.conductSurvey();
                    break;
                case "6":
                    this.surveyEditor();
                    break;
                case "7":
                    this.calculateGrade();
                    break;
                case "8":
                    if(this.returnBack()){
                        return;
                    }
                    break;
                default:
                    this.menu_output.render("Invalid input");
            }

        }
    }

    public void generateNewSurvey(){
        SecondMenu second_menu = new SecondMenu(true);
        if (this.modified_Unsaved_current_survey){
            String response_integer = this.menu_input.GetThroughPrompt("You have an unsaved survey, Press 5 to continue or 1 to start over");
//            switch(response_integer){
//                case "5":
//                    this.Survey_Renewal();
//                    return null;
//
//                case "1":
//                    break;
//                default:
//                    return null;

            if (response_integer.equals("5")){
                this.Survey_Renewal();
            }
            else if(!response_integer.equals("1") && !response_integer.equals("5")){
                return;
            }
        }
        this.Current_Survey = second_menu.LoaderForMenuItems(this.getNewSurvey());
        this.modified_Unsaved_current_survey = true;
        this.NoneSurvey();

    }

    public void renderCurrentSurvey(){
        MainSurvey curr_survey = this.renderAllContentFiles("render/display");
        if (curr_survey!=null){
            ArrayList<Questions> survey_question_temp = curr_survey.retrieveSurveyQuestions();
            int totalQuestions = survey_question_temp.size();
            for (int i = 0; i < totalQuestions; i++) {
                Questions temp = survey_question_temp.get(i);
                this.menu_output.renderSingleLineTogether((i + 1) + ") ");
                temp.render(this.Tester());
                this.menu_output.render("");
            }

        }
        else{
            return;
        }
    }
    protected boolean returnBack() {
        if(this.Current_Survey != null){
            String Condition = "Pass";
            while(Condition=="Pass"){
                String curr_conf = this.menu_input.GetThroughPrompt("If you have an unsaved test/survey, changes will be unsaved, enter 'Yes' to confirm");
                if(curr_conf.equals("Yes")){
                    return true;
                }else{
                    return false;
                }
            }
        }
        return true;
    }

    public void desiredSurveyLoader(){
        System.out.println("here");
        MainSurvey curr_survey = this.renderAllContentFiles("load");
        System.out.println("here");
        if(this.Current_Survey!=null){
            String response = this.menu_input.GetThroughPrompt("you have an active survey, Enter 'Y' to overwrite");
            if (!response.equalsIgnoreCase("Y")){
                return;
            }
        }
        if (curr_survey==null){
            return;
        }
        this.Current_Survey= curr_survey;
        this.modified_Unsaved_current_survey = false;
        this.menu_output.render("survey loaded successfully, add more question to the survey by entering 5");
    }

    private String askForFileName() {
        return this.menu_input.GetThroughPrompt("Please enter a name for your " + this.getDesiredFileType());
    }

    private String createFilePath(String fileName) {
        return "Serializable" + this.delimiter + this.getDesiredFileType() + "s" + this.delimiter + fileName + ".ser";
    }
    private void setSelectedPathAndSurveyName(File[] surveyFiles, int selectedOption) {
        this.current_Path= surveyFiles[selectedOption - 1].getPath();
        this.current_survey_name = surveyFiles[selectedOption - 1].getName();
    }
    private void displayCurrentSurveyOption(int fileCount) {
        this.menu_output.render((fileCount + 1) + "." + "Current " + this.getDesiredFileType());
    }
    private int getSelectedOption() {
        int selectedOption = this.menu_input.getNumberInputThroughPrompt("Enter the number for the survey you want to open");
        return selectedOption;
    }

    private boolean fileExists(String filePath) {
        return new File(filePath).exists();
    }

    private boolean confirmOverwrite(String fileName) {
        String confirm = this.menu_input.GetThroughPrompt("A file with the name '" + fileName + "' already exists. Are you sure you want to overwrite it? Enter 'Y' to overwrite, anything else to stop");
        return confirm.equals("Y");
    }


    public void CurrentSurveySaver(MainSurvey Curr_Survey){
        if (this.Current_Survey != null) {
            String fileName = askForFileName();
            if (fileName == null) {
                return;
            }

            String path = createFilePath(fileName);
            if (path == null) {
                return;
            }

            if (fileExists(path)) {
                boolean overwriteConfirmation = confirmOverwrite(fileName);
                if (!overwriteConfirmation) {
                    this.menu_output.render("Save is canceled");
                    return;
                }
            }

            Curr_Survey.setNameOfCurrentSurvey(fileName);
            this.menu_output.processSerialization(this.Current_Survey,path);

            this.menu_output.render(this.getDesiredFileType() + " has been saved");
            this.modified_Unsaved_current_survey = false;
        } else {
            this.menu_output.render("No " + this.getDesiredFileType() + " is in use at the moment to save");
        }
    }
    private void checkSurveyNull() {
        this.NoneSurvey();
    }
    private void displayNoActiveSurveyMessage() {
        this.menu_output.render("No current " + this.getDesiredFileType() + " is active");
    }
    private boolean isNoCurrentSurveyActive() {
        return this.Current_Survey == null;
    }
    public void Survey_Renewal(){
        if (this.isNoCurrentSurveyActive()) {
            this.displayNoActiveSurveyMessage();
        } else {
            SecondMenu Second_menu = new SecondMenu(true);
            this.Current_Survey = Second_menu.LoaderForMenuItems(this.Current_Survey);
            this.checkSurveyNull();
        }
    }
    private File[] getSurveyFiles() {
        return new File("Serializable" + this.delimiter + this.getDesiredFileType() + "s").listFiles();
    }


    protected void calculateGrade() {
        MainSurvey curr_survey = this.renderAllContentFiles("grade");
        curr_survey.renderGrades();
    }

    public void renderQuestions(MainSurvey curr_survey){
        ArrayList<Questions> survey_question_temp = curr_survey.retrieveSurveyQuestions();
        int totalQuestions = survey_question_temp.size();
        for (int i = 0; i < totalQuestions; i++) {
            Questions temp = survey_question_temp.get(i);
            this.menu_output.renderSingleLineTogether((i + 1) + ") ");
            temp.render(this.Tester());
            this.menu_output.render("");
        }


    }

    private void saveSurveyChanges(MainSurvey survey) {
        this.menu_output.processSerialization(survey, this.current_Path);
        this.menu_output.render("Survey saved successfully!");
    }
    public void surveyEditor(){
        MainSurvey curr_survey = this.renderAllContentFiles("modify");
        String loop_condition = "Pass";
        while(loop_condition=="Pass"){
            this.renderQuestions(curr_survey);
            this.menu_output.render("Enter the index of the question you want to modify, enter 'Back' to go back, 'Save' to save the changes");
            String response = this.menu_input.getSurveyInput();
            if (response.equalsIgnoreCase("Back")) {
                return;
            }
            else if(response.equalsIgnoreCase("Save")){
                this.saveSurveyChanges(curr_survey);
                return;
            }
            else{
                try{
                    int curr_index = Integer.parseInt(response);
                    if (isValidQuestionIndex(curr_survey, curr_index)) {
                        curr_survey.getCurrentQuestion(curr_index).QuestionEdit(this.Tester());
                        break;
                    }
                    else{
                        this.menu_output.render("Enter a valid question index");
                    }
                }
                catch(NumberFormatException e){
                    this.menu_output.render("Enter valid question index");
                }
            }
        }
    }
    private boolean isValidQuestionIndex(MainSurvey survey, int questionIndex) {
        return questionIndex > 0 && questionIndex <= survey.getLengthOfQuestion();
    }



    public void NoneSurvey(){
        if (this.Current_Survey.getLengthOfQuestion()!=0){
            this.modified_Unsaved_current_survey=true;
            return;
        }
        this.Current_Survey=null;
        this.modified_Unsaved_current_survey=false;

    }

    public String Tester(){
        String Condition = "Pass";
        if (Condition =="Fail"){
            return "Fail";
        }
        return Condition;
    }




}
