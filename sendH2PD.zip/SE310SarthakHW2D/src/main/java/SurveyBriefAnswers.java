import java.util.*;
public class SurveyBriefAnswers extends Essay{
    private int character_limit;
    private ArrayList<String> accurateAnswers;
    private HashMap<String,Integer> tabulationList;
//    Constructor
    public SurveyBriefAnswers(){
        this.accurateAnswers=new ArrayList<>();
        this.tabulationList= new HashMap<>();
        this.Essay_Answers = new ArrayList<>();
    }


    @Override
    public void renderTabs() {
        this.Question_Output.render("Tabulation:");
        Iterator<Map.Entry<String, Integer>> iterator = this.tabulationList.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            String key = entry.getKey();
            Integer value = entry.getValue();

            this.Question_Output.render(key + ": " + value);
        }
    }


    @Override
    public Integer AnswerPrompter(String Condition) {
        this.Question_Output.render("the limit of this prompt is:" + this.character_limit + " words");
        String curr_chosen="";
        if (Condition=="Fail"){
            this.ResultPrompter();
            return 0;
        }
        curr_chosen = this.ResultPrompter();
        if(this.accurateAnswers.contains(curr_chosen)){
            return 10;
        }else{
            return 0;
        }
    }
    @Override
    public void QuestionLoader(){
//      this.QuestionEdit("");
        this.PromptLoader("Enter a prompt for the short answer");
//        this.validate(Input);
        this.limitSetter();
    }

    public void renderAccurateAnswer(){
        this.Question_Output.render("limit:" + this.character_limit);
        for (int i = 0; i < this.accurateAnswers.size(); i++) {
            this.Question_Output.renderSingleLineTogether( (i + 1 + ")" + this.accurateAnswers.get(i) + " " + "\n"));
        }

    }

    public void limitSetter(){
        this.character_limit = this.Question_Input.getNumberInputThroughPrompt("Enter a limit of characters for the short answer");
        if (this.character_limit!=0){
            return;
        }
        else if (this.character_limit < 1) {
            this.Question_Output.render("Limit must be at least 1");
            limitSetter();
        }


    }
    public String ResultPrompter(){
        String Conditon = "Pass";
        while (Conditon=="Pass"){
            String curr = this.Question_Input.GetThroughPrompt("Please enter the short answer text below");
            if (this.character_limit<curr.split(" ").length){
                this.Question_Output.render("Maximum amount of total words exceeded! ");
                continue;
            }
            this.Essay_Answers.add(curr);
            if (this.tabulationList.get(curr)==null){
                this.tabulationList.put(curr,1);
            }
            else{
                this.tabulationList.replace(curr,this.tabulationList.get(curr)+1);
            }
            return curr;
        }
        return "";
    }
    @Override
    public Integer getAccuratePoints() {
        return 10;
    }


}
