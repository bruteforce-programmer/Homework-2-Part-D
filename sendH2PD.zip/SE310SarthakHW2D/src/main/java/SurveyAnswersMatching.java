import java.util.*;
import java.util.stream.IntStream;

public class SurveyAnswersMatching extends Questions {

    HashMap<String, String> accurateAnswers;
    HashMap<String, String> responses;
    Set<String> firstColumn;
    HashMap<HashMap<String, String>, Integer> tabulationList;
    Set<String> secondColumn;
    ArrayList<String> matchedItems;
    ArrayList<HashMap<String,String>> responsesFromUsers;

    int matchesTotal;

    //    Constructor
    public SurveyAnswersMatching() {
        this.responses = new HashMap<>();
        this.tabulationList = new HashMap<>();
        this.matchedItems = new ArrayList<>();
        this.accurateAnswers = new HashMap<>();
        this.responsesFromUsers = new ArrayList<>();
    }


    private String getItemAt(List<String> list, int index) {
        int count = 0;
        for (String item : list) {
            if (count == index) {
                return item;
            }
            count++;
        }
        throw new IndexOutOfBoundsException("Invalid index: " + index);
    }

    private void displayOptions(List<String> options) {
        int index = 1;
        for (String option : options) {
            this.Question_Output.renderSingleLineTogether(index + ") " + option + " ");
            index++;
        }
    }

    //  Load a question
//    No return since void
//    No Function paramters
    @Override
    public void QuestionLoader() {
        this.PromptLoader("Enter a prompt for your question:");

        int matchesTotal = 0;
        String ConditionCheck = "Pass";
        while (ConditionCheck == "Pass") {
            matchesTotal = this.Question_Input.getNumberInputThroughPrompt("Enter total number of matching choices:");
            if (matchesTotal < 2) {
                this.Question_Output.render("Please enter more than 1 choice.");
            } else if (matchesTotal > 1000) {
                this.Question_Output.render("Please enter less than 1000 choices.");
            } else if (matchesTotal == 0) {
                continue;
            } else {
                ConditionCheck = "Fail";
            }
        }

        this.Question_Output.render("Enter choices for the first column:");
        Set<String> firstColumn = this.columnLoader();

        this.Question_Output.render("Enter choices for the second column:");
        Set<String> secondColumn = this.columnLoader();

        this.responsesFromUsers = new ArrayList<>();
        this.matchesTotal = matchesTotal;
        this.firstColumn = firstColumn;
        this.secondColumn = secondColumn;
    }

    //    column loader for survey questions
//    No parameters
//    Returns Set<String>
    public Set<String> columnLoader() {
        Set<String> column = this.Question_Input.getMultipleSurveyInput("Match choice number", this.matchesTotal);
        return column;
    }
    private String getMatchByIndex(HashSet<String> set, int index) {
        int i = 1;
        for (String item : set) {
            if (i == index) {
                return item;
            }
            i++;
        }
        return null;
    }
    //    Load the correct answer
//    no return since void
//    Function Parameter: Answer(String)
    @Override
    public void CorrectAnswerLoader(String Answer) {
        this.matchedItems = new ArrayList<>();
        this.accurateAnswers = new HashMap<>();
        this.Question_Output.render("enter the correct answer for each match by typing in the index number");
        HashSet<String> tempColumn2 = new HashSet<>(this.secondColumn);
        for (String element : this.firstColumn){
            String loop_condition = "Pass";
            while(loop_condition=="Pass"){
                int curr_index=1;
                for (String curr_match : tempColumn2){
                    this.Question_Output.renderSingleLineTogether(curr_index + ")" + curr_match + " ");
                    curr_index++;
                }
                curr_index = this.Question_Input.getNumberInputThroughPrompt("\nPlease select the correct answer for " + element);
                if (curr_index < 1 || curr_index > tempColumn2.size() || curr_index == 0) {
                    this.Question_Output.render("Invalid number");
                    continue;
                }
                String curr_match = getMatchByIndex(tempColumn2, curr_index);
                if (this.matchedItems.contains(curr_match)||curr_match==null){
                    this.Question_Output.render("The choice you entered is not found/already entered.");
                }
                else{
                    tempColumn2.remove(curr_match);
                    this.accurateAnswers.put(element,curr_match);
                    this.matchedItems.add(curr_match);
                    break;
                }
            }
        }
    }


    //  render/display the questions
//    no return
//    no function parameter
    @Override
    public void render(String Condition) {
        List<String> column1List = new ArrayList<>(this.firstColumn);
        List<String> column2List = new ArrayList<>(this.secondColumn);
        String Temporary_Prompt = this.Question_Instructions;
        this.Question_Output.render(Temporary_Prompt);

        int size = Math.min(column1List.size(), column2List.size());

        for (int i = 0; i < size; i++) {
            String value1 = column1List.get(i);
            String value2 = column2List.get(i);
            this.Question_Output.render(value1 + "      |      " + value2);
        }
        if (Condition == "Pass") {
            this.Question_Output.render("Correct answers:");
            int curr_index = 1;
            for (String key : this.accurateAnswers.keySet()) {
                String val = this.accurateAnswers.get(key);
                this.Question_Output.render(curr_index + ")" + key + " -> " + val);
                curr_index++;
            }
        }

    }

    ;

    //  Edits a question
//    No return since void
//    Function parameter: Condition(String): is overloaded in some classes
    @Override
    public void QuestionEdit(String Condition) {
        if (Condition == "Pass") {
            int choice = this.Question_Input.getNumberInputThroughPrompt("1) Modify prompt\n2) Modify left column\n3) Modify right column\n4) Modify answer\n5) Back");

            switch (choice) {
                case 1:
                    this.PromptLoader("Enter a new prompt");
                    break;
                case 2:
                    this.columnEditor(true, true);
                    break;
                case 3:
                    this.columnEditor(false, true);
                    break;
                case 4:
                    this.CorrectAnswerLoader("");
                    this.Question_Output.render("Answer updated");
                    break;
                case 5:
                    return;
                default:
                    this.Question_Output.render("Invalid choice");
                    break;
            }

            QuestionEdit(Condition);
        } else {
            int choice = this.Question_Input.getNumberInputThroughPrompt("1) Modify prompt\n2) Modify left column\n3) Modify right column\n4) Back");

            switch (choice) {
                case 1:
                    this.PromptLoader("Enter a new prompt");
                    break;
                case 2:
                    this.columnEditor(true, false);
                    break;
                case 3:
                    this.columnEditor(false, false);
                    break;
                case 4:
                    return;
                default:
                    this.Question_Output.render("Invalid choice");
                    break;
            }

            QuestionEdit(Condition);
        }
    }

    // Render right column(Made two different methods for columns render to simplify rendering and editing)
//    No parameters
//    no returns since void
    public void renderRightColumn() {
        int counter = 0;
        for (String Element : this.secondColumn)
            this.Question_Output.renderSingleLineTogether((counter + 1 + ")" + Element + " " + "\n"));
        counter++;
    }

    // Render Left column
//    No parameters
//    no returns since void
    public void renderLeftColumn() {
        int counter = 0;
        for (String Element : this.firstColumn)
            this.Question_Output.renderSingleLineTogether((counter + 1 + ")" + Element + " " + "\n"));
        counter++;
    }


    //    Edits the columns
//    Parameter: Side(Boolean), Condition(Boolean)
//    No return since void
    public void columnEditor(Boolean Side, Boolean Condition) {
        Set<String> column = Side ? new HashSet<>(this.firstColumn) : new HashSet<>(this.secondColumn);
        String Loop_Condition = "Pass";
        while (Loop_Condition == "Pass") {
            if (Side) {
                this.renderLeftColumn();
            } else {
                this.renderRightColumn();
            }
            int index = this.Question_Input.getNumberInputThroughPrompt("\nEnter the index of the item (1-" + column.size() + "): ");
            if (index == 0 || index < 1 || index > column.size()) {
                this.Question_Output.render("The index you have entered is not valid.");
                continue;
            }
            Iterator<String> iterator = column.iterator();
            String currentItem = null;
            for (int i = 1; i <= index; i++) {
                currentItem = iterator.next();
            }
            String Second_Loop_Condition = "Pass";
            while (Second_Loop_Condition == "Pass") {
                String response = this.Question_Input.GetThroughPrompt("Please enter the replacement text for this item: ");

                if (column.contains(response)) {
                    this.Question_Output.render("You have already entered this text. Please try again.");
                    continue;
                }

                iterator.remove();
                column.add(response);
                if (Condition == true) {
                    if (Side == true) {
                        String Answer_Holder = this.accurateAnswers.get(currentItem);
                        this.accurateAnswers.remove(currentItem);
                        this.accurateAnswers.put(response, Answer_Holder);
                    } else {
                        for (Map.Entry<String, String> entry : this.accurateAnswers.entrySet()) {
                            if (entry.getValue().equals(currentItem)) {
                                this.accurateAnswers.replace(entry.getKey(), response);
                                break;
                            }
                        }
                    }
                }
                this.Question_Output.render("Modified Successfully");
                return;
            }

        }

    }
    @Override
    public void renderResponses() {
        this.Question_Output.render("Replies:");
        int i = 0;
        while (i < this.responsesFromUsers.size()) {
            HashMap<String, String> response = this.responsesFromUsers.get(i);
            for (Map.Entry<String, String> entry : response.entrySet()) {
                String key = entry.getKey();
                String val = entry.getValue();
                this.Question_Output.render(key + "--->" + val);
            }
            this.Question_Output.render("");
            i++;
        }
    }

    @Override
    public Integer getAccuratePoints() {
        return 10;
    }

    @Override
    public void renderTabs() {
        this.Question_Output.render("Tabulate:");
        Iterator<Map.Entry<HashMap<String, String>, Integer>> iterator = this.tabulationList.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<HashMap<String, String>, Integer> entry = iterator.next();
            HashMap<String, String> key = entry.getKey();
            Integer value = entry.getValue();

            this.Question_Output.render(value.toString());

            Iterator<Map.Entry<String, String>> innerIterator = key.entrySet().iterator();
            while (innerIterator.hasNext()) {
                Map.Entry<String, String> innerEntry = innerIterator.next();
                this.Question_Output.render(innerEntry.getKey() + "---->" + innerEntry.getValue());
            }

            this.Question_Output.render("");
        }
    }

    //    Prompts the answer
//    no return since void
//    Function parameter: None
    @Override
    public Integer AnswerPrompter(String Condition) {
        this.responses = new HashMap<>();
        this.matchedItems = new ArrayList<>();
        this.Question_Output.render("Enter the answer by typing in the index");
        List<String> Second_Column = new ArrayList<>(this.secondColumn);
        for (String s : this.firstColumn) {
            String Loop_Condition = "Pass";
            while (Loop_Condition == "Pass") {
                displayOptions(Second_Column);
                int index = this.Question_Input.getNumberInputThroughPrompt("\nPlease select an option for " + s);

                if (index == 0 || index > Second_Column.size() || index < 1) {
                    this.Question_Output.render("Invalid index.");
                    continue;
                }

                String match = getItemAt(Second_Column, index - 1);
                if (!this.secondColumn.contains(match) || this.matchedItems.contains(match)) {
                    this.Question_Output.render("The choice entered is not found/already entered.");
                } else {
                    Second_Column.remove(match);
                    this.responses.put(s, match);
                    this.matchedItems.add(match);
                    break;
                }
            }
        }
        this.responsesFromUsers.add(this.responses);
        if (!this.tabulationList.containsKey(this.responses)) {
            this.tabulationList.put(this.responses, 1);
        } else {
            this.tabulationList.put(this.responses, this.tabulationList.get(this.responses) + 1);
        }
        if (Condition == "Pass") {
            if (this.responses.equals(this.accurateAnswers)) {
                return 10;
            }
            return 0;
        }

    return 0;

        }


    }




